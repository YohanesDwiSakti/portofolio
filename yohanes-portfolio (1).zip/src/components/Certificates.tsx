import { motion } from "motion/react";
import { Award, GraduationCap, Code } from "lucide-react";

const certificates = [
  {
    id: "CERT_01",
    title: "Bootcamp AI 101",
    subtitle: "Exploring Object Detection with NVIDIA Expert",
    organization: "HIMTI BINUS University Malang",
    date: "Oct 2024",
    achievement: "Participant",
    icon: <Cpu size={24} />,
    image: "https://picsum.photos/seed/certificate/800/600"
  },
  {
    id: "CERT_02",
    title: "Dean's List Certificate",
    subtitle: "Outstanding Academic Achievement",
    organization: "School of Computer Science, BINUS",
    date: "Dec 2025",
    achievement: "Dean's List 2025",
    icon: <GraduationCap size={24} />,
    image: "https://picsum.photos/seed/academic/800/600"
  },
  {
    id: "CERT_03",
    title: "C Programming",
    subtitle: "Certificate of Completion",
    organization: "BNCC (Computer Club)",
    date: "Aug 2025",
    achievement: "High Distinction",
    icon: <Code size={24} />,
    image: "https://picsum.photos/seed/coding/800/600"
  }
];

// Re-defining icons to avoid import issues if Cpu is missing
import { Cpu } from "lucide-react";

export default function Certificates() {
  return (
    <section id="certificates" className="py-24">
      <div className="mb-16">
        <h2 className="font-mono text-primary text-sm mb-2 tracking-widest uppercase">
          // Certifications
        </h2>
        <h3 className="text-3xl font-bold text-white">
          Academic & Technical Credentials
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {certificates.map((cert) => (
          <div
            key={cert.id}
            className="minimal-card p-6 flex flex-col group"
          >
            <div className="flex justify-between items-start mb-6">
              <div className="text-primary opacity-80">
                {cert.icon}
              </div>
              <span className="font-mono text-[10px] text-text-muted uppercase tracking-widest">
                {cert.id}
              </span>
            </div>

            <div className="aspect-video w-full overflow-hidden mb-6 rounded border border-border">
              <img
                src={cert.image}
                alt={cert.title}
                className="w-full h-full object-cover grayscale opacity-70 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex-grow">
              <h4 className="font-bold text-lg text-white mb-1 group-hover:text-primary transition-colors">
                {cert.title}
              </h4>
              <p className="font-mono text-[10px] text-primary/70 uppercase tracking-wider mb-4">
                {cert.subtitle}
              </p>
              <div className="space-y-1 mb-6">
                <p className="text-text-muted text-xs">
                  {cert.organization}
                </p>
                <p className="text-text-muted/50 text-[10px] font-mono">
                  {cert.date}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <p className="font-mono text-[10px] text-white uppercase tracking-widest">
                {cert.achievement}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
